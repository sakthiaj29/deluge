// Keep the top of your script the same
lucide.createIcons();

let projects = [];

const r = 40;
const circumference = 2 * Math.PI * r;

init();

async function init() {
  const project_config = {
    app_name: "syngrid-project-management",
    report_name: "Project_Report"
  };
  const task_config = {
    app_name: "syngrid-project-management",
    report_name: "All_Tasks"
  };
  const timesheet_config = {
    app_name: "syngrid-project-management",
    report_name: "All_Timesheet"
  };

  try {
    const res1 = await ZOHO.CREATOR.DATA.getRecords(project_config);
    const res2 = await ZOHO.CREATOR.DATA.getRecords(task_config);
    const res3 = await ZOHO.CREATOR.DATA.getRecords(timesheet_config);


    const allProjects = res1?.data || [];
    const allTasks = res2?.data || [];

    projects.length = 0; // reset global

    allProjects.forEach(pRec => {
      const project = {
        id: pRec.ID,
        name: pRec.Project_Name || "Untitled Project",
        status: pRec.Status || "Unknown",
        startDate: pRec.Start_Date || "-",
        endDate: pRec.End_Date || "-",
        priority: pRec.Priority || "-",
        tasks: [],
        totalMinutes: 0
      };

      allTasks.forEach(tRec => {
        const taskProjectId = tRec.Project?.ID ?? tRec.Project;
        if (String(taskProjectId) === String(project.id)) {
          const task = {
            id: tRec.ID,
            name: tRec.Task_Title || "Untitled Task",
            status: tRec.Status || "Unknown",
            actual_start_date: tRec.Actual_Start_Date || "--",
            actual_end_date: tRec.Actual_End_Date || "--",
            work_start_date: tRec.Work_Start_Date || "--",
            work_end_date: tRec.Work_End_Date || "--",
            employees: [],
            totalMinutes: 0
          };

             tRec.Time_Log.forEach(ts => {
            const tsTaskId = ts.Task_ID?.ID ?? ts.Task_ID;
              const empName = ts.Employee?.Name ?? ts.Employee ?? "Unknown";
              let emp = task.employees.find(e => e.name === empName);
              if (!emp) {
                emp = { name: empName, totalMinutes:0, work: [] };
                task.employees.push(emp);
              }

              const hours = parseInt(ts.Hour ?? 0, 10) || 0;
              const minutes = parseInt(ts.Minutes ?? ts.Minute ?? ts.Min ?? 0, 10) || 0;
              const minutesTotal = hours * 60 + minutes;

              emp.totalMinutes += minutesTotal;
              task.totalMinutes += minutesTotal;
              project.totalMinutes += minutesTotal;

              emp.work.push({
                name:ts.Timesheet_Name ?? "--",
                date: ts.Date_field ?? ts.Date ?? "--",
                hour: hours,
                min: minutes,
                status: ts.Status ?? ts.Timesheet_Status ?? "--",
                notes:ts.Notes ?? "--"
              });
          });

          project.tasks.push(task);
        }
      });

      projects.push(project);
    });

    render();
  } catch (err) {
    console.error("Failed to load Creator records:", err);
    alert("No project records available.");
  }
}

function render() {
  const projectsContainer = document.getElementById("projectsContainer");
  const popup = document.getElementById("projectPopup");
  const popupTitle = document.getElementById("popupProjectTitle");
  const projectDetails = document.getElementById("projectDetails");
  const tasksContainer = document.getElementById("tasksContainer");

  if (!projectsContainer) {
    console.warn("No #projectsContainer element found — rendering aborted.");
    return;
  }

  // ---- Summary cards ----
  setText("totalProjects", projects.length || 0);
  setText("completedProjects", projects.filter(p => p.status === "Completed").length);
  setText("activeProjects", projects.filter(p => p.status === "Active").length);
  setText("testingProjects", projects.filter(p => p.status === "In Testing").length);

  // ---- Render projects ----
  projectsContainer.innerHTML = "";
  projects.forEach(project => {
    const safeStatusClass = (project.status || "").replace(/\s+/g, "");
    const card = document.createElement("div");
    card.className = `project-card ${safeStatusClass}`;
    card.innerHTML = `
      <h2 class="name-truncate">${escapeHtml(project.name)}</h2>
      <div class="project-header">
        <span class="status-badge ${safeStatusClass}">${escapeHtml(project.status)}</span>
      </div>
      <p>Priority: <b>${escapeHtml(project.priority)}</b></p>
      <div class="circle-container">
        <div class="circle-wrap">
          <svg viewBox="0 0 100 100">
            <circle class="bg" cx="50" cy="50" r="40"></circle>
            <circle class="progress" id="progress-${project.id}" cx="50" cy="50" r="40" transform="rotate(-90 50 50)"></circle>
          </svg>
          <div class="circle-label">
            <div class="percent" id="percent-${project.id}">0%</div>
          </div>
        </div>
      </div>
    `;
    card.onclick = () => openProjectPopup(project);
    projectsContainer.appendChild(card);

    updateProgress(project);
  });

  // ---- Export handler ----
  const exportBtn = document.getElementById("exportProjects");
  if (exportBtn) {
    exportBtn.onclick = () => exportProjectsCSV();
  }

  // ---- Progress updater ----
  function updateProgress(project) {
    const circle = document.querySelector(`#progress-${project.id}`);
    const percentText = document.getElementById(`percent-${project.id}`);
    if (!circle || !percentText) return;

    const completed = project.tasks.filter(t => t.status === "Completed").length;
    const total = project.tasks.length;
    circle.style.strokeDasharray = circumference;

    let percent = total > 0 ? (completed / total) * 100 : 0;
    percent = Math.max(0, Math.min(100, percent));
    const offset = circumference - (percent / 100) * circumference;
    circle.style.strokeDashoffset = offset;
    percentText.textContent = Math.round(percent) + "%";
  }

  // ---- Popup ----
  function openProjectPopup(project) {
    if (!popup) return;
    popup.style.display = "flex";
    popupTitle.textContent = project.name;
    projectDetails.innerHTML = `
      <p><b>Status:</b> ${escapeHtml(project.status)}</p>
      <p><b>Priority:</b> ${escapeHtml(project.priority)}</p>
      <p><b>Start Date:</b> ${escapeHtml(project.startDate)}</p>
      <p><b>End Date:</b> ${escapeHtml(project.endDate)}</p>
      <p><b>Total Hours:</b> ${formatMinutes(project.totalMinutes)}</p>
    `;

    tasksContainer.innerHTML = "";

    if (!project.tasks || project.tasks.length === 0) {
      // Show "No Task Found" with image
      tasksContainer.innerHTML = `
        <div class="no-task">
          <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" 
               alt="No tasks" style="width:120px;opacity:0.7;margin-bottom:10px;">
          <p style="font-size:16px;color:#666;">No Tasks Found</p>
        </div>
      `;
      return;
    }

    project.tasks.forEach(task => {
      const taskCard = document.createElement("div");
      taskCard.className = "task-card";
      const safeTaskStatus = (task.status || "").replace(/\s+/g, "");

      const result=( task.actual_end_date<task.work_end_date && (task.status!="Completed" || task.status!="Closed") )?"Overdue Task":"";
      
     taskCard.innerHTML = `
  <div class="task-title">
    <img src="https://cdn-icons-png.flaticon.com/512/1001/1001371.png" 
         alt="task" style="width:18px;height:18px;margin-right:6px;vertical-align:middle;">
    <span>${escapeHtml(task.name)}</span>
    <span> - ${formatMinutes(task.totalMinutes)}</span>
    <span style="color:red"> ${result} </span>
    <span class="status ${safeTaskStatus}">${escapeHtml(task.status)}</span>
    <i data-lucide="chevron-down" class="caret" aria-hidden="true"></i>
  </div>
  <span style="font-size:12px">  Start date: ${task.actual_start_date} &nbsp;&nbsp; End date: ${task.actual_end_date}</span>
  <div class="task-details" id="task-${task.id}" style="display:none;"></div>
`;


      // Toggle details + rotate the caret
      taskCard.onclick = () => {
        toggleTaskDetails(task.id, task.employees);
        const caretEl = taskCard.querySelector(".caret");
        if (caretEl) caretEl.classList.toggle("rotate");
      };

      tasksContainer.appendChild(taskCard);
    });

    // VERY IMPORTANT: render Lucide icons created in this popup
    if (window.lucide?.createIcons) {
      lucide.createIcons();
    }
  }

  function toggleTaskDetails(taskId, employees) {
    const detailDiv = document.getElementById(`task-${taskId}`);
    if (!detailDiv) return;

    if (detailDiv.style.display === "block") {
      detailDiv.style.display = "none";
      detailDiv.innerHTML = "";
      return;
    }

    detailDiv.style.display = "block";
    if (!employees || employees.length === 0) {
      detailDiv.innerHTML = `<div class="no-data">👎 No Timesheet found</div>`;
      return;
    }

    detailDiv.innerHTML = employees.map(emp => {
      const rows = (emp.work || []).map(w => {
        const tip = [
          `Title: ${w.name}`,
          `Date: ${w.date}`,
          `Notes: ${w.notes}`
        ].join("\n\n");
        return `
          <div class="ts-row" data-tip="${escapeHtml(tip)}">
            📅 ${escapeHtml(w.date)} — ${w.hour}h ${w.min}m 
            <span class="status">(${escapeHtml(w.status)})</span>
          </div>
        `;
      }).join("");
      return `
        <div class="employee-entry">
          <strong>${escapeHtml(emp.name)}</strong><br/>
          ${rows}
        </div>
        <div class="task-total"><b>Total Hours:</b> ${formatMinutes(emp.totalMinutes)}</div>
      `;
    }).join("");
  }

  // ---- CSV Export ----
  function exportProjectsCSV() {
    const rows = [[
      "Project Name","Status","Priority","Start Date","End Date","Total Hours",
      "Task Name","Task Status","Employee","Date","Hours","Minutes","Timesheet Status"
    ]];

    projects.forEach(p => {
      (p.tasks && p.tasks.length ? p.tasks : [{}]).forEach(t => {
        (t.employees && t.employees.length ? t.employees : [{}]).forEach(e => {
          (e.work && e.work.length ? e.work : [{}]).forEach(w => {
            rows.push([
              p.name || "",
              p.status || "",
              p.priority || "",
              p.startDate || "",
              p.endDate || "",
              formatMinutes(p.totalMinutes || 0),
              t.name || "",
              t.status || "",
              e.name || "",
              w.date || "",
              w.hour || "",
              w.min || "",
              w.status || ""
            ]);
          });
        });
      });
    });

    const csvContent = rows.map(r => r.map(v => `"${String(v ?? "")}"`).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "projects_export.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  // ---- Close popup ----
  const closePopupBtn = document.getElementById("closePopup");
  if (closePopupBtn) {
    closePopupBtn.onclick = () => { if (popup) popup.style.display = "none"; };
  }
  window.onclick = e => { if (e.target === popup && popup) popup.style.display = "none"; };

  // ---- Utils ----
  function formatMinutes(mins) {
    const n = Number(mins) || 0;
    const h = Math.floor(n / 60);
    const m = n % 60;
    return `${h}h ${m}m`;
  }

  function escapeHtml(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }
}
