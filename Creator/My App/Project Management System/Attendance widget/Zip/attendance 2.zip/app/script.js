/* Attendance checkin/checkout - robust version for Zoho Creator widget/page
   - Re-queries DOM elements after page changes
   - Uses ZOHO.embeddedApp.on("PageLoad") when available (SPA navigation)
   - Waits for getInitParams() and getRecords() before rendering UI
   - Awaits server update before changing state
*/
let loginuser = "";

(function () {
  const DURATION_MS = 1500;
  let btn, statusEl, path, toast;
  let circumference;
  let raf, startTime, completed = false, holding = false;
  let isCheckedIn = null; // unknown until server tells us
  let busy = false;
  let initAttempts = 0;
  const MAX_INIT_ATTEMPTS = 20;
  let listenersAdded = false;
  const RADIUS = 45; // same as your ring r

  // -------------------------
  // element setup + init flow
  // -------------------------
  function setupElements() {
    btn = document.getElementById("checkBtn");
    statusEl = document.getElementById("status");
    path = document.getElementById("progressPath");
    toast = document.getElementById("toast") || null;

    if (!btn || !statusEl || !path) return false;

    circumference = 2 * Math.PI * RADIUS;
    path.setAttribute("stroke-dasharray", `${circumference} ${circumference}`);
    resetRing();

    if (!listenersAdded) {
      btn.addEventListener("pointerdown", onPointerDown);
      btn.addEventListener("pointerup", onPointerUp);
      btn.addEventListener("pointercancel", () => endHold(true));
      btn.addEventListener("pointerleave", () => holding && endHold(true));
      listenersAdded = true;
    }
    return true;
  }

  function trySetupAndInit() {
    if (setupElements()) {
      // get login user and fetch state
      ZOHO.CREATOR.UTIL.getInitParams().then((res) => {
        loginuser = res.loginUser;
        initCheckState();
      }).catch((err) => {
        console.warn("getInitParams failed:", err);
        // try to init anyway (loginuser may be blank)
        initCheckState();
      });
      return;
    }

    initAttempts++;
    if (initAttempts < MAX_INIT_ATTEMPTS) {
      setTimeout(trySetupAndInit, 250);
    } else {
      console.error("Attendance widget: required DOM elements not found (checkBtn/status/progressPath).");
    }
  }

  // run on normal load
  document.addEventListener("DOMContentLoaded", trySetupAndInit);

  // visible again (tab / app foreground)
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      ZOHO.CREATOR.UTIL.getInitParams().then((res) => {
        loginuser = res.loginUser;
        initCheckState();
      }).catch(() => initCheckState());
    }
  });

  // If embeddedApp SDK exists, listen for PageLoad (handles SPA navigation inside Creator/CRM)
  if (window.ZOHO && ZOHO.embeddedApp && typeof ZOHO.embeddedApp.on === "function") {
    ZOHO.embeddedApp.on("PageLoad", function (data) {
      // reset attempts and try re-setup (DOM might be replaced)
      initAttempts = 0;
      trySetupAndInit();
    });
    // init SDK if available
    if (typeof ZOHO.embeddedApp.init === "function") {
      try { ZOHO.embeddedApp.init(); } catch (e) { /* ignore */ }
    }
  }

  // -------------------------
  // Server-sync functions
  // -------------------------
  async function initCheckState() {
    isCheckedIn = null;
    updateUILoading();

    const today = new Date().toISOString().split("T")[0];
    const criteria = `((Email = "${loginuser}") && (Dates = "${today}"))`;

    try {
      const res = await ZOHO.CREATOR.DATA.getRecords({
        app_name: "syngrid-project-management",
        report_name: "All_Time",
        criteria: criteria,
      });
      if (res && res.data && res.data.length) {
        const rec = res.data[0];
        const checkinCount = (rec.Checkin || []).length;
        const checkoutCount = (rec.Checkout || []).length;
        isCheckedIn = checkinCount > checkoutCount;
      } else {
        isCheckedIn = false;
      }
    } catch (err) {
      console.error("initCheckState error:", err);
      // fallback to not checked in (safe default)
      isCheckedIn = false;
    }

    updateUI();
  }

  function updateUILoading() {
    if (!statusEl) return;
    statusEl.textContent = "Fetching status...";
    if (btn) {
      btn.textContent = "...";
      btn.classList.remove("checkin", "checkout");
      btn.setAttribute("aria-pressed", "false");
      btn.disabled = true;
    }
  }

  function updateUI() {
    if (!btn || isCheckedIn === null) {
      if (btn) btn.disabled = true;
      return;
    }

    btn.disabled = false;
    const checkState = isCheckedIn ? "CHECK-OUT" : "CHECK-IN";
    const cssAdd = isCheckedIn ? "checkout" : "checkin";
    const cssRemove = isCheckedIn ? "checkin" : "checkout";

    btn.textContent = checkState;
    btn.classList.remove(cssRemove);
    btn.classList.add(cssAdd);
    path.classList.remove(cssRemove);
    path.classList.add(cssAdd);

    statusEl.textContent = isCheckedIn ? "Already checked in" : "Not checked in";
    btn.setAttribute("aria-pressed", String(isCheckedIn));
  }

  // -------------------------
  // Hold / UI ring handlers
  // -------------------------
  function onPointerDown(e) {
    if (busy) return;
    completed = false;
    resetRing();
    btn.setPointerCapture?.(e.pointerId);
    startHold();
  }

  function onPointerUp(e) {
    btn.releasePointerCapture?.(e.pointerId);
    endHold(true);
  }

  function startHold() {
    holding = true;
    startTime = performance.now();
    raf = requestAnimationFrame(step);
  }

  function endHold(cancel) {
    holding = false;
    cancelAnimationFrame(raf);
    if (!completed && cancel) resetRing();
  }

  function step(now) {
    if (!holding) return;
    const t = Math.min((now - startTime) / DURATION_MS, 1);
    setRingProgress(t);
    if (t >= 1) {
      completed = true;
      holding = false;
      // async toggle (await inside)
      toggleCheck();
    } else {
      raf = requestAnimationFrame(step);
    }
  }

  function setRingProgress(t) {
    if (!path) return;
    path.setAttribute("stroke-dashoffset", circumference * (1 - t));
  }

  function resetRing() {
    if (!path) return;
    path.setAttribute("stroke-dashoffset", circumference);
  }

  // -------------------------
  // Toggle + server update (awaits server)
  // -------------------------
  async function toggleCheck() {
    if (isCheckedIn === null) return;
    if (busy) return;
    busy = true;
    btn.disabled = true;

    const now = new Date();
    const date = now.toLocaleDateString("en-GB", {
      day: "2-digit", month: "2-digit", year: "numeric"
    });
    const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const today = new Date().toISOString().split("T")[0];

    btn.classList.add("pulse");
    setTimeout(() => btn.classList.remove("pulse"), 350);

    const btnStatus = isCheckedIn ? "Checkout" : "Checkin";

    // Wait for server result before flipping UI
    const success = await addOrUpdateRecord(today, date, time, btnStatus);

    // re-fetch authoritative state either way
    await initCheckState();

    if (success) {
      showToast("Successfully " + (isCheckedIn ? "Checked In" : "Checked Out"));
    } else {
      showToast("Action failed — please try again.");
    }

    resetRing();
    completed = false;
    busy = false;
    if (btn) btn.disabled = false;
  }

  async function addOrUpdateRecord(today, date, time, btnStatus) {
    const criteria = `((Email = "${loginuser}") && (Dates = "${today}"))`;

    try {
      const res = await ZOHO.CREATOR.DATA.getRecords({
        app_name: "syngrid-project-management",
        report_name: "All_Time",
        criteria: criteria,
      });

      if (res && res.data && res.data.length) {
        return await updateRecord(res.data[0].ID, res.data[0], btnStatus, time);
      } else {
        return await addRecord(date, time);
      }
    } catch (err) {
      console.error("API getRecords failed in addOrUpdateRecord", err);
      // try adding as fallback
      return await addRecord(date, time);
    }
  }

  function addRecord(date, time) {
    const createConfig = {
      app_name: "syngrid-project-management",
      form_name: "Time",
      payload: {
        data: {
          Name: "Sakthi S",
          Email: loginuser,
          Dates: date,
          Checkin: [{ Time: time }],
        },
      },
    };

    return ZOHO.CREATOR.DATA.addRecords(createConfig).then((resp) => {
      // Creator success codes vary; 3000 is often success for update — handle generically
      return !!(resp && (resp.code === 3000 || resp.data));
    }).catch((err) => {
      console.error("addRecord error", err);
      return false;
    });
  }

  function updateRecord(recordId, oldData, btnStatus, time) {
    const key = btnStatus === "Checkin" ? "Checkin" : "Checkout";
    const oldArray = oldData[key] || [];
    const newArray = oldArray.map((i) => ({ Time: i.Time }));
    newArray.push({ Time: time });

    const updateConfig = {
      app_name: "syngrid-project-management",
      report_name: "All_Time",
      id: recordId,
      payload: { data: { Email: loginuser, [key]: newArray } },
    };

    return ZOHO.CREATOR.DATA.updateRecordById(updateConfig).then((resp) => {
      return !!(resp && resp.code === 3000);
    }).catch((err) => {
      console.error("updateRecord error", err);
      return false;
    });
  }

  function showToast(message) {
    if (!toast) return alert(message);
    toast.textContent = message;
    toast.className = "show";
    setTimeout(() => {
      toast.className = toast.className.replace("show", "");
    }, 1500);
  }
})();
