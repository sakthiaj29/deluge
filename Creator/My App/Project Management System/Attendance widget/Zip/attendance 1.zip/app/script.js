let loginuser = "";

(function () {
  const DURATION_MS = 1500;
  const btn = document.getElementById("checkBtn");
  const statusEl = document.getElementById("status");
  const path = document.getElementById("progressPath");

  const r = 45,
    circumference = 2 * Math.PI * r;
  path.setAttribute("stroke-dasharray", `${circumference} ${circumference}`);
  resetRing();

  let raf, startTime, completed = false, holding = false;
  let isCheckedIn = false;

  // ✅ On Load (works web + mobile)
  document.addEventListener("DOMContentLoaded", () => {
    ZOHO.CREATOR.UTIL.getInitParams().then((res) => {
      loginuser = res.loginUser;
      initCheckState();
    });
  });

  // ✅ On Tab Switch (web + portal app)
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      ZOHO.CREATOR.UTIL.getInitParams().then((res) => {
        loginuser = res.loginUser;
        initCheckState();
      });
    }
  });

  // ✅ On Mobile Resume / App Foreground (Portal App)
  window.addEventListener("pageshow", () => {
    ZOHO.CREATOR.UTIL.getInitParams().then((res) => {
      loginuser = res.loginUser;
      initCheckState();
    });
  });

  // ---------------------------------------------------------
  // Functions
  // ---------------------------------------------------------

  function initCheckState() {
    const today = new Date().toISOString().split("T")[0];
    const criteria = `((Email = "${loginuser}") && (Dates = "${today}"))`;

    ZOHO.CREATOR.DATA.getRecords({
      app_name: "syngrid-project-management",
      report_name: "All_Time",
      criteria: criteria,
    }).then((res) => {
      if (res?.data?.length) {
        const rec = res.data[0];
        const checkinCount = (rec.Checkin || []).length;
        const checkoutCount = (rec.Checkout || []).length;

        // If checkins > checkouts → considered checked in
        isCheckedIn = checkinCount > checkoutCount;
      } else {
        isCheckedIn = false; // no record → default check-in
      }
      updateUI();
    }).catch((err) => {
      console.error("Fetch error:", err);
      isCheckedIn = false;
      updateUI();
    });
  }

  btn.addEventListener("pointerdown", (e) => {
    completed = false;
    resetRing();
    btn.setPointerCapture?.(e.pointerId);
    startHold();
  });

  btn.addEventListener("pointerup", (e) => {
    btn.releasePointerCapture?.(e.pointerId);
    endHold(true);
  });

  btn.addEventListener("pointercancel", () => endHold(true));
  btn.addEventListener("pointerleave", () => holding && endHold(true));

  function startHold() {
    holding = true;
    startTime = performance.now();
    raf = requestAnimationFrame(step);
  }

  function endHold(cancel) {
    holding = false;
    cancelAnimationFrame(raf);
    if (!completed && cancel) resetRing();
  }

  function step(now) {
    if (!holding) return;
    const t = Math.min((now - startTime) / DURATION_MS, 1);
    setRingProgress(t);
    if (t >= 1) {
      completed = true;
      holding = false;
      toggleCheck();
    } else {
      raf = requestAnimationFrame(step);
    }
  }

  function setRingProgress(t) {
    path.setAttribute("stroke-dashoffset", circumference * (1 - t));
  }

  function resetRing() {
    path.setAttribute("stroke-dashoffset", circumference);
  }

  function toggleCheck() {
    const now = new Date();
    const date = now.toLocaleDateString("en-GB", {
      day: "2-digit", month: "2-digit", year: "numeric"
    });
    const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const today = new Date().toISOString().split("T")[0];

    btn.classList.add("pulse");
    setTimeout(() => btn.classList.remove("pulse"), 350);

    let btnStatus = isCheckedIn ? "Checkout" : "Checkin";
    statusEl.textContent = `${btnStatus}ed ${date} at ${time}`;
    isCheckedIn = !isCheckedIn; // flip state

    const msg = isCheckedIn ? "Checked In" : "Checked Out";

    addOrUpdateRecord(today, date, time, btnStatus);
    updateUI();
    setTimeout(resetRing, 10);
    showToast("Successfully " + msg);
    completed = false;
    
  }

  function updateUI() {
    const checkState = isCheckedIn ? "CHECK-OUT" : "CHECK-IN";
    const cssAdd = isCheckedIn ? "checkout" : "checkin";
    const cssRemove = isCheckedIn ? "checkin" : "checkout";

    btn.textContent = checkState;
    btn.classList.remove(cssRemove);
    btn.classList.add(cssAdd);
    path.classList.remove(cssRemove);
    path.classList.add(cssAdd);
    statusEl.textContent = isCheckedIn ? "Already checked in" : "Not checked in";
    btn.setAttribute("aria-pressed", isCheckedIn);
  }

  async function addOrUpdateRecord(today, date, time, btnStatus) {
    const criteria = `((Email = "${loginuser}") && (Dates = "${today}"))`;

    ZOHO.CREATOR.DATA.getRecords({
      app_name: "syngrid-project-management",
      report_name: "All_Time",
      criteria: criteria,
    }).then((res) => {
      if (res?.data?.length) {
        updateRecord(res.data[0].ID, res.data[0], btnStatus, time);
      } else {
        addRecord(date, time);
      }
    }).catch((err) => {
      console.error("❌ API Error:", err);
      addRecord(date, time);
    });
  }

  function addRecord(date, time) {
    const createConfig = {
      app_name: "syngrid-project-management",
      form_name: "Time",
      payload: {
        data: {
          Name: "Sakthi S",
          Email: loginuser,
          Dates: date,
          Checkin: [{ Time: time }],
        },
      },
    };
    ZOHO.CREATOR.DATA.addRecords(createConfig).then((resp) => console.log("Created:", resp));
  }

  function updateRecord(recordId, oldData, btnStatus, time) {
    let key = btnStatus === "Checkin" ? "Checkin" : "Checkout";
    let oldArray = oldData[key] || [];
    let newArray = oldArray.map((i) => ({ Time: i.Time }));
    newArray.push({ Time: time });

    const updateConfig = {
      app_name: "syngrid-project-management",
      report_name: "All_Time",
      id: recordId,
      payload: { data: { Email: loginuser, [key]: newArray } },
    };

    ZOHO.CREATOR.DATA.updateRecordById(updateConfig).then((resp) => {
      if (resp.code == 3000) console.log("Updated:", resp);
    });
  }

  function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.className = "show";

    setTimeout(() => {
      toast.className = toast.className.replace("show", "");
    }, 1500);
  }
})();
